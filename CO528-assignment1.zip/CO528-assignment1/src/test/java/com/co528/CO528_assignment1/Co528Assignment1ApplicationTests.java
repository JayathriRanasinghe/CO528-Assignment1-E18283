package com.co528.CO528_assignment1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Co528Assignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
