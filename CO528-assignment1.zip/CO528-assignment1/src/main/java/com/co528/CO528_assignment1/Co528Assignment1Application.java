package com.co528.CO528_assignment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Co528Assignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Co528Assignment1Application.class, args);
	}

}
